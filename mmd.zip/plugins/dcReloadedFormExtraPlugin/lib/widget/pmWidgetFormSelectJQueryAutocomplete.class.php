<?php

class pmWidgetFormSelectJQueryAutocomplete extends sfWidgetFormSelect
{
  /**
   * Renders the widget.
   *
   * @param  string $name        The element name
   * @param  string $value       The value selected in this widget
   * @param  array  $attributes  An array of HTML attributes to be merged with the default HTML attributes
   * @param  array  $errors      An array of errors for the field
   *
   * @return string An HTML tag string
   *
   * @see sfWidgetForm
   */
  public function render($name, $value = null, $attributes = array(), $errors = array())
  {
    $attributes["class"] = "select_jquery_autocomplete";
    return parent::render($name, $value, $attributes, $errors);
  }
  
  /**
   * Gets the JavaScript paths associated with the widget.
   *
   * @return array An array of JavaScript paths
   */
  public function getJavaScripts()
  {
    return array_merge(parent::getJavaScripts(), array("/dcReloadedFormExtraPlugin/js/select_jquery_autocomplete.js"));
  }
  
  /**
   * Gets the stylesheet paths associated with the widget.
   *
   * The array keys are files and values are the media names (separated by a ,):
   *
   *   array('/path/to/file.css' => 'all', '/another/file.css' => 'screen,print')
   *
   * @return array An array of stylesheet paths
   */
  public function getStylesheets()
  {
    return array_merge(parent::getStylesheets(), array("/dcReloadedFormExtraPlugin/css/select_jquery_autocomplete.css" => "all"));
  }
}