<?php

/**
 * sfGuardUserPermission filter form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage filter
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: sfGuardUserPermissionFormFilter.class.php 12896 2008-11-10 19:02:34Z fabien $
 */
class sfGuardUserPermissionFormFilter extends BasesfGuardUserPermissionFormFilter
{
  public function configure()
  {
  }
}
