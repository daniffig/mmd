<?php

/**
 * sfGuardUser module helper.
 *
 * @package    sfGuardPlugin
 * @subpackage sfGuardUser
 * @author     Fabien Potencier
 * @version    SVN: $Id: sfGuardUserGeneratorHelper.class.php 12896 2008-11-10 19:02:34Z fabien $
 */
class sfGuardUserGeneratorHelper extends BaseSfGuardUserGeneratorHelper
{
}
