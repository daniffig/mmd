<?php

/**
 * ##MODULE_NAME## exporter form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage ##MODULE_NAME##
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: exporterForm.php 12474 2008-10-31 10:41:27Z mtorres $
 */
class ##MODULE_NAME##ExporterForm extends Base##UC_MODULE_NAME##ExporterForm
{
}
