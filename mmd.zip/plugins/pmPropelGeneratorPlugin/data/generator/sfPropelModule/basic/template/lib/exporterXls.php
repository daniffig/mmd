[?php

class Base<?php echo ucfirst($this->getModuleName()) ?>ExporterXls extends pmExporterXls
{

}
