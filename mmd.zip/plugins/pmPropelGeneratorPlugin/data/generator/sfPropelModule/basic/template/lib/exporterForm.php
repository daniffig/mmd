[?php

class Base<?php echo ucfirst($this->getModuleName()) ?>ExporterForm extends pmExporterForm
{

}
