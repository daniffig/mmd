<div id="sf_admin_exportation" style="display: none">
  <div id="sf_admin_exportation_form" style="display: none;"></div>
  <div id="sf_admin_exportation_ajax_indicator" style="display: none; text-alig: center; ">
    [?php echo image_tag($configuration->getExportationAjaxIndicatorPath()) ?]
    [?php echo __('Please wait...', array(), 'sf_admin') ?]
  </div>
</div>
