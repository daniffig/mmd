[?php

class Base<?php echo ucfirst($this->getModuleName()) ?>ExporterCsv extends pmExporterCsv
{

}
