<?php

class pmExporterDecoratorPass extends pmExporterDecoratorBase
{
  public function render($value)
  {
    return $value;
  }
}
